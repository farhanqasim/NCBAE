<script>
    const Toast = Swal.mixin({
        toast: true,
        position: 'top',
        showConfirmButton: false,
        timer: 2500,
        timerProgressBar: true,
    });

    <?php if($message = Session::get("success")): ?>
    Toast.fire({
        icon: 'success',
        title: '<?php echo e($message); ?>'
    })
    <?php endif; ?>

    <?php if($message = Session::get("danger")): ?>
    Toast.fire({
        icon: 'error',
        title: '<?php echo e($message); ?>'
    })
    <?php endif; ?>

    <?php if($message = Session::get("warning")): ?>
    Toast.fire({
        icon: 'warning',
        title: '<?php echo e($message); ?>'
    })
    <?php endif; ?>
</script>
<?php /**PATH C:\xampp\htdocs\ncba\resources\views/admin/includes/messages.blade.php ENDPATH**/ ?>