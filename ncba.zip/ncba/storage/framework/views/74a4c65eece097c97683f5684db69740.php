 <div class="nk-footer">
                    <div class="container-fluid">
                        <div class="nk-footer-wrap">
                            <div class="nk-footer-copyright"> &copy; 2022 DashLite. Template by <a href="https://softnio.com" target="_blank">Softnio</a>
                            </div>
                          
                        </div>
                    </div>
                </div><?php /**PATH C:\xampp\htdocs\ncba\resources\views/admin/includes/footer.blade.php ENDPATH**/ ?>