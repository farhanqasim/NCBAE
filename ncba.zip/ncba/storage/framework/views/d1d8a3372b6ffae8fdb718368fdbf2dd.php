
<?php $__env->startSection('title','Student Detail'); ?>
<?php $__env->startSection('content'); ?>

<div class="container-fluid">
  <div class="nk-content-inner">
    <div class="nk-content-body">
      <div class="nk-block-head nk-block-head-sm">
        <div class="nk-block-between g-3">
          <div class="nk-block-head-content">
            <h3 class="nk-block-title page-title">Student Detail</h3>

          </div>

        </div>
      </div><!-- .nk-block-head -->
      <div class="nk-block">
        <div class="row g-gs">
          <div class="col-sm-6 col-lg-1 col-xxl-3"></div>
          <div class="gallery card">
            <div class="col-sm-6 col-lg-10 col-xxl-3">

              <a class="gallery-image popup-image">
                <img class="w-100 rounded-top" src="<?php echo e(asset('storage/student_images')); ?>/<?php echo e($user->profile); ?>" alt="" height="300px">
              </a>

            </div>
            <div class="row">
    <div class="col-md-12">
        <table class="table">
            <tr>
                <th scope="row">Name</th>
                <td><?php echo e($user->name); ?></td>
            </tr>
            <tr>
                <th scope="row">Father's Name</th>
                <td><?php echo e($user->father_name); ?></td>
            </tr>
            <tr>
                <th scope="row">CNIC</th>
                <td><?php echo e($user->cnic); ?></td>
            </tr>
            <tr>
                <th scope="row">Qualification</th>
                <td><?php echo e($user->qualification); ?></td>
            </tr>
            <tr>
                <th scope="row">Total Marks</th>
                <td><?php echo e($user->total_marks); ?></td>
            </tr>
            <tr>
                <th scope="row">Obtain Marks</th>
                <td><?php echo e($user->obtain_marks); ?></td>
            </tr>
            <tr>
                <th scope="row">Program</th>
                <td><?php echo e($user->program); ?></td>
            </tr>
            <tr>
                <th scope="row">Durations</th>
                <td><?php echo e($user->duration); ?></td>
            </tr>
            <tr>
                <th scope="row">Contact</th>
                <td><?php echo e($user->contact); ?></td>
            </tr>
            <tr>
                <th scope="row">Gender</th>
                <td><?php echo e($user->gender); ?></td>
            </tr>
            <tr>
                <th scope="row">Email </th>
                <td><?php echo e($user->email); ?></td>
            </tr>
        </table>
    </div>
</div>


            

           
          </div>

        </div>
      </div><!-- .nk-block -->
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\projects\laravel\ncba\resources\views/admin/pages/view-studentinfo.blade.php ENDPATH**/ ?>