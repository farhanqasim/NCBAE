
<?php $__env->startSection('title','Edit Student'); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
  <div class="nk-content-inner">
    <div class="nk-content-body">
      <div class="components-preview">
        <div class="nk-block-head nk-block-head-lg wide-sm">
          <div class="nk-block-head-content">

            <h2 class="nk-block-title fw-normal">Student Information</h2>

          </div>
        </div>

        <div class="nk-block nk-block-lg">

          <div class="card">
            <div class="card-inner">
             <form method="POST" action="<?php echo e(route('update-student', $user)); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="row g-gs">
                  <div class="col-md-6">
                    <div class="form-group">
                      <label class="form-label" for="fva-full-name">Full Name</label>
                      <div class="form-control-wrap">
                        <input type="text" class="form-control" id="fva-full-name" name="name" value="<?php echo e($user->name); ?>" required>
                      </div>
                    </div>
                  </div>
                  <div class="col-md-6">
                    <div class="form-group">
                      <label class="form-label" for="fva-full-Father">Father Name</label>
                      <div class="form-control-wrap">
                        <input type="text" class="form-control" id="fva-full-Father" name="father_name" value="<?php echo e($user->father_name); ?>" required>
                      </div>
                    </div>
                  </div>
                  <div class="col-md-6">
                    <div class="form-group">
                      <label class="form-label" for="fva-full-CNIC">CNIC</label>
                      <div class="form-control-wrap">
                        <input type="text" class="form-control" id="fva-full-CNIC" name="cnic" value="<?php echo e($user->cnic); ?>" required>
                      </div>
                    </div>
                  </div>
                  <div class="col-md-6">
                    <div class="form-group">
                      <label class="form-label" for="fva-full-qualification">Recent Qualification</label>
                      <div class="form-control-wrap">
                        <input type="text" class="form-control" id="fva-full-qualification" name="qualification" value="<?php echo e($user->qualification); ?>" required>
                      </div>
                    </div>
                  </div>
                  <div class="col-md-6">
                    <div class="form-group">
                      <label class="form-label" for="fva-full-total">Total marks</label>
                      <div class="form-control-wrap">
                        <input type="number" class="form-control" id="fva-full-total" name="total_marks" value="<?php echo e($user->total_marks); ?>" required>
                      </div>
                    </div>
                  </div>
                  <div class="col-md-6">
                    <div class="form-group">
                      <label class="form-label" for="fva-full-Obtain">Obtain marks</label>
                      <div class="form-control-wrap">
                        <input type="number" class="form-control" id="fva-full-Obtain" name="obtain_marks" value="<?php echo e($user->obtain_marks); ?>" required>
                      </div>
                    </div>
                  </div>
                  <div class="col-md-6">
                    <div class="form-group">
                      <label class="form-label" for="fva-full-Program">Put Program</label>
                      <div class="form-control-wrap">
                        <input type="text" class="form-control" id="fva-full-Program" name="program" value="<?php echo e($user->program); ?>" required>
                      </div>
                    </div>
                  </div>
                  <div class="col-md-6">
                    <div class="form-group">
                      <label class="form-label" for="fva-full-Duration">Duration</label>
                      <div class="form-control-wrap">
                        <select class="form-control form-select" id="fva-Duration" name="duration" data-placeholder="Select a Duration" required>
                          <option label="empty" value=""></option>
                          <option value="4 Year" <?php echo e($user->duration === '4 Year' ? 'selected' : ''); ?>>4 Year</option>
                          <option value="2 Year" <?php echo e($user->duration === '2 Year' ? 'selected' : ''); ?>>2 Year</option>
                        </select>
                      </div>
                    </div>
                  </div>
                   <div class="col-md-6">
                    <div class="form-group">
                      <label class="form-label" for="fv-phone">Phone</label>
                      <div class="form-control-wrap">
                        <div class="input-group">
                         
                          <input type="text" name="contact" class="form-control" value="<?php echo e($user->contact); ?>">
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="col-md-6">
                    <div class="form-group">
                      <label class="form-label" for="fv-Password">Profile Image</label>
                      <div class="form-control-wrap">
                        <div class="input-group">

                          <input type="file" name="profile" class="form-control"><br>
                          <img src="<?php echo e(asset('storage/student_images')); ?>/<?php echo e($user->profile); ?>" alt="Student Profile Image" width="50px" height="auto">
                        </div>
                      </div>
                    </div>
                  </div>
                
                  <div class="col-md-6">
                    <div class="form-group">
                      <label class="form-label" for="fva-email">Email address</label>
                      <div class="form-control-wrap">
                     
                        <input type="text" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="fva-email" name="email" value="<?php echo e($user->email); ?>" required>
                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                      </div>
                    </div>
                  </div>

                  <div class="col-md-6">
                    <div class="form-group">
                      <label class="form-label" for="fva-full-Duration">Alumni Student</label>
                      <div class="form-control-wrap">
                        <select class="form-control form-select" id="fva-Duration" name="alumni" data-placeholder="" required>
                          <option label="Select Alumni" value=""></option>
                          <option value="Yes">Yes</option>
                          <option value="No">No</option>
                        </select>
                      </div>
                    </div>
                  </div>

                  <div class="col-md-6">
                    <div class="form-group">
                      <label class="form-label" for="fva-full-Program">Company Name</label>
                      <div class="form-control-wrap">
                        <input type="text" class="form-control" id="fva-full-Program" name="company_name" value="" required>
                      </div>
                    </div>
                  </div>
                 
                  <div class="col-md-12">
                    <div class="form-group">
                      <button type="submit" class="btn btn-lg btn-primary">Save Informations</button>
                    </div>
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>

      </div>
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\projects\laravel\ncba\resources\views/admin/pages/edit-student.blade.php ENDPATH**/ ?>