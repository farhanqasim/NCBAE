  <!-- ======= Header ======= -->
  <header id="header" class="header fixed-top d-flex align-items-center">
    <div class="container-fluid d-flex align-items-center justify-content-between">

      <a href="" class="logo d-flex align-items-center me-auto me-xl-0">

        <img src="<?php echo e(asset('assets/img/logo.svg')); ?>" alt="">
      </a>

      <!-- Nav Menu -->
      <nav id="navmenu" class="navmenu" style="display: flex; justify-content:space-between; column-gap:20px;">
        <ul class=""  style=" margin-right:auto">
          <li><a href="<?php echo e(url('/')); ?>" class="active">Home</a></li>
          <li><a href="#about">About</a></li>
          <li><a href="#posts">Posts</a></li>
          <li><a href="#events">Event</a></li>
          
          <li><a href="<?php echo e(route('blog')); ?>">Blog</a></li>

          <li><a href="#contact">Contact</a></li>

        </ul>
        <ul style="display: flex; column-gap:10px; float:right">
            <?php if(Route::has('login')): ?>
                <?php if(auth()->guard()->check()): ?>
                    <li><a class="btn-getstarted" href="#">Add Post</a></li>
                    <li><a class="btn-getstarted" href="#">View Post</a></li>
                    <li>
                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <a class="btn-getstarted" href="#" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">Sign out</a>
                        </form>
                    </li>
                </ul>
                <i class="mobile-nav-toggle d-xl-none bi bi-list"></i>
              </nav><!-- End Nav Menu -->
                <?php else: ?>
                    <a class="btn-getstarted" href="<?php echo e(route('login')); ?>">Get Started</a>
                <?php endif; ?>
            <?php endif; ?>
        </ul>


    </div>
  </header><!-- End Header -->
<?php /**PATH C:\xampp\htdocs\ncba\resources\views/include/header.blade.php ENDPATH**/ ?>