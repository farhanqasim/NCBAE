<!DOCTYPE html>
<html lang="zxx" class="js">

<head>
    
    <meta charset="utf-8">
    <meta name="author" content="Softnio">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="A powerful and conceptual apps base dashboard template that especially build for developers and programmers.">
    <!-- Fav Icon  -->
    <link rel="shortcut icon" href="./images/favicon.png">
    <!-- Page Title  -->
   <title><?php echo $__env->yieldContent('title'); ?></title>
    <!-- StyleSheets  -->
    <link rel="stylesheet" href="<?php echo e(asset('admin/assets/css/dashlite.css')); ?>">
    <link id="skin-default" rel="stylesheet" href="<?php echo e(asset('admin/assets/css/theme.css')); ?>">
</head>

<body class="nk-body bg-lighter npc-default has-sidebar ">
    <div class="nk-app-root">
        <!-- main @s -->
        <div class="nk-main ">
            <!-- sidebar @s -->
            <div class="nk-sidebar nk-sidebar-fixed is-light " data-content="sidebarMenu">
                 <?php echo $__env->make('admin.includes.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <!-- sidebar @e -->
           
            <div class="nk-wrap ">
                
                <div class="nk-header nk-header-fixed is-light">
                    <?php echo $__env->make('admin.includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
               
                
                <div class="nk-content ">
                    <?php echo $__env->yieldContent('content'); ?>
                </div>
               
                <!-- footer @s -->
                <?php echo $__env->make('admin.includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <!-- footer @e -->
            </div>
           
        </div>
        
    </div>
    <script src="<?php echo e(asset('admin/assets/js/bundle.js')); ?>"></script>
    <script src="<?php echo e(asset('adminassets/js/scripts.js')); ?>"></script>
    <script src="<?php echo e(asset('adminassets/js/charts/chart-ecommerce.js')); ?>"></script>
       <?php echo $__env->make('admin.includes.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>

</html><?php /**PATH C:\xampp\htdocs\ncba\resources\views/admin/layouts/app.blade.php ENDPATH**/ ?>