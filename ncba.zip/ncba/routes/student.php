<?php

use App\Http\Controllers\HomeController;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Student\StudentController;





Route::get('dashboard', [StudentController::class,"student_dashboard"])->name('student_home');
