@extends('admin.layouts.app')
@section('title','Add Student')
@section('content')
<div class="container-fluid">
  <div class="nk-content-inner">
    <div class="nk-content-body">
      <div class="components-preview">
        <div class="nk-block-head nk-block-head-lg wide-sm">
          <div class="nk-block-head-content">

            <h2 class="nk-block-title fw-normal">Student Information</h2>

          </div>
        </div>

        <div class="nk-block nk-block-lg">

          <div class="card">
            <div class="card-inner">
             <form method="POST" action="{{route('submit-student')}}" enctype="multipart/form-data">
                @csrf
                <div class="row g-gs">
                  <div class="col-md-6">
                    <div class="form-group">
                      <label class="form-label" for="fva-full-name">Full Name</label>
                      <div class="form-control-wrap">
                        <input type="text" class="form-control" id="fva-full-name" name="name" required>
                      </div>
                    </div>
                  </div>
                  <div class="col-md-6">
                    <div class="form-group">
                      <label class="form-label" for="fva-full-Father">Father Name</label>
                      <div class="form-control-wrap">
                        <input type="text" class="form-control" id="fva-full-Father" name="father_name" required>
                      </div>
                    </div>
                  </div>
                  <div class="col-md-6">
                    <div class="form-group">
                      <label class="form-label" for="fva-full-CNIC">CNIC</label>
                      <div class="form-control-wrap">
                        <input type="text" class="form-control" id="fva-full-CNIC" name="cnic" required>
                      </div>
                    </div>
                  </div>
                  <div class="col-md-6">
                    <div class="form-group">
                      <label class="form-label" for="fva-full-qualification">Recent Qualification</label>
                      <div class="form-control-wrap">
                        <input type="text" class="form-control" id="fva-full-qualification" name="qualification" required>
                      </div>
                    </div>
                  </div>
                  <div class="col-md-6">
                    <div class="form-group">
                      <label class="form-label" for="fva-full-total">Total marks</label>
                      <div class="form-control-wrap">
                        <input type="number" class="form-control" id="fva-full-total" name="total_marks" required>
                      </div>
                    </div>
                  </div>
                  <div class="col-md-6">
                    <div class="form-group">
                      <label class="form-label" for="fva-full-Obtain">Obtain marks</label>
                      <div class="form-control-wrap">
                        <input type="number" class="form-control" id="fva-full-Obtain" name="obtain_marks" required>
                      </div>
                    </div>
                  </div>
                  <div class="col-md-6">
                    <div class="form-group">
                      <label class="form-label" for="fva-full-Program">Put Program</label>
                      <div class="form-control-wrap">
                        <input type="text" class="form-control" id="fva-full-Program" name="program" required>
                      </div>
                    </div>
                  </div>
                  <div class="col-md-6">
                    <div class="form-group">
                      <label class="form-label" for="fva-full-Duration">Duration</label>
                      <div class="form-control-wrap">
                        <select class="form-control form-select" id="fva-Duration" name="duration" data-placeholder="Select a Duration" required>
                          <option label="empty" value=""></option>
                          <option value="4 Year">4 Year</option>
                          <option value="2 Year">2 Year</option>
                        </select>
                      </div>
                    </div>
                  </div>
                   <div class="col-md-6">
                    <div class="form-group">
                      <label class="form-label" for="fv-phone">Phone</label>
                      <div class="form-control-wrap">
                        <div class="input-group">
                         
                          <input type="text" name="contact" class="form-control" required>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="col-md-6">
                    <div class="form-group">
                      <label class="form-label" for="fv-Password">Profile Image</label>
                      <div class="form-control-wrap">
                        <div class="input-group">
                         
                          <input type="file" name="profile" class="form-control" required>
                        </div>
                      </div>
                    </div>
                  </div>
                   <div class="col-md-12">
                    <div class="form-group">
                      <label class="form-label" for="fv-phone">Gender</label>
                      <div class="form-control-wrap">
                        <ul class="custom-control-group">
                          <li>
                            <div class="custom-control custom-radio custom-control-pro no-control">
                              <input type="radio" class="custom-control-input" name="gender" id="alt-sex-male" value="male" required>
                              <label class="custom-control-label" for="alt-sex-male">Male</label>
                            </div>
                          </li>
                          <li>
                            <div class="custom-control custom-radio custom-control-pro no-control">
                              <input type="radio" class="custom-control-input" name="gender" id="alt-sex-female" value="female" required>
                              <label class="custom-control-label" for="alt-sex-female">Female</label>
                            </div>
                          </li>
                        
                        </ul>
                      </div>
                    </div>
                  </div>

                  <div class="col-md-6">
                    <div class="form-group">
                      <label class="form-label" for="fva-email">Email address</label>
                      <div class="form-control-wrap">
                     
                        <input type="text" class="form-control @error('email') is-invalid @enderror" id="fva-email" name="email" value="{{ old('email') }}" required>
                        @error('email')
                            <span class="invalid-feedback" role="alert">
                                <strong>{{ $message }}</strong>
                            </span>
                        @enderror
                      </div>
                    </div>
                  </div>
                  
                  <div class="col-md-6">
                    <div class="form-group">
                      <label class="form-label" for="fv-Password">Password</label>
                      <div class="form-control-wrap">
                        <div class="input-group">                        
                          <input type="text" name="password" class="form-control" required>
                        </div>
                      </div>
                    </div>
                  </div>
                 
                   
                  <div class="col-md-12">
                    <div class="form-group">
                      <button type="submit" class="btn btn-lg btn-primary">Save Informations</button>
                    </div>
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>

      </div>
    </div>
  </div>
</div>

@endsection